package com.boa.training.avroschema;

import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class Receiver {
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
			Properties props = new Properties();
			props.put("bootstrap.servers", "localhost:9092");
			props.put("group.id", "CountryCounter");
			props.put("key.deserializer",
			"org.apache.kafka.common.serialization.StringDeserializer");
			props.put("value.deserializer",
			"io.confluent.kafka.serializers.KafkaAvroDeserializer");
			props.put("schema.registry.url", "http://localhost:8081");
			String topic = "customerContacts";
			KafkaConsumer consumer = new
			KafkaConsumer(props);
			consumer.subscribe(Collections.singletonList(topic));
			System.out.println("Reading topic:" + topic);
			while (true) {
			ConsumerRecords<String, GenericRecord> records =
			consumer.poll(Duration.ofMinutes(2));
			for (ConsumerRecord<String, GenericRecord> record: records) {
				ObjectMapper mapper=new ObjectMapper();
				Customer c=mapper.readValue(record.value().toString().getBytes(), Customer.class);
			System.out.println("Current customer name is: " +
			c.getName());
			}
			
			}
	}

}