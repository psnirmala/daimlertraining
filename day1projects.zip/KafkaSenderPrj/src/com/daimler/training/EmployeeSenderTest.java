package com.daimler.training;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.daimler.training.domain.Employee;
import com.daimler.training.serializer.EmployeeSerializer;


public class EmployeeSenderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Properties props=new Properties();
		props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, EmployeeSerializer.class.getName());
		KafkaProducer<String, Employee> producer=new KafkaProducer<>(props);
		String topic="emp-topic";
		
		Employee employee1=new Employee(5001, "Rakesh Sharma", "Developer");
		Employee employee2=new Employee(5002, "Arvind Nirni", "Accountant");
		
		ProducerRecord<String, Employee> record1=new ProducerRecord<String, Employee>(topic, "emp-1", employee1);
		producer.send(record1);
		
		ProducerRecord<String, Employee> record2=new ProducerRecord<String, Employee>(topic, "emp-2", employee2);
		producer.send(record2);
		
		System.out.println("messages sent");
		producer.close();
	}

}
