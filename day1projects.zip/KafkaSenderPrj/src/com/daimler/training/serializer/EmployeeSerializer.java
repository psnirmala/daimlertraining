package com.daimler.training.serializer;

import org.apache.kafka.common.serialization.Serializer;

import com.daimler.training.domain.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeSerializer implements Serializer<Employee> {

private ObjectMapper mapper=new ObjectMapper();

	@Override
	public byte[] serialize(String topic, Employee emp) {
		// TODO Auto-generated method stub
		byte[] array=null;
		try {
			String jsonContent=mapper.writeValueAsString(emp);
			System.out.println("serializing "+jsonContent);
			array=jsonContent.getBytes();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return array;
	}

}
