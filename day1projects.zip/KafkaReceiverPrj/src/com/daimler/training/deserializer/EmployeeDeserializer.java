package com.daimler.training.deserializer;

import java.io.IOException;

import org.apache.kafka.common.serialization.Deserializer;

import com.daimler.training.domain.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeDeserializer implements Deserializer<Employee>{

	
	ObjectMapper mapper=new ObjectMapper();
	@Override
	public Employee deserialize(String topic, byte[] array) {
		// TODO Auto-generated method stub
		Employee employee=null;

			try {
				employee=mapper.readValue(array, Employee.class);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		return employee;
	}

}
